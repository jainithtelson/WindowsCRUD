﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AddresBook
{
    public partial class Form1 : Form
    {
        //You can see the connection string settings in App.Config file. as we are using entity framwork the connection string is automatically added. 
        AddressBookEntities addressBookEntities = new AddresBook.AddressBookEntities();
        public Form1()
        {
            InitializeComponent();
            BindGrid();
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            Address address = new AddresBook.Address();
            address.Name = txtName.Text;
            address.AddressLine1 = txtAddres.Text;
            address.City = txtCity.Text;
            address.Country = txtCountry.Text;
            address.Contact = txtContact.Text;
            if (BtnSave.Text == "Save")
            {
               
                //we already created an object addressBookEntities at beginning on the class
                addressBookEntities.Addresses.Add(address);
                addressBookEntities.SaveChanges();
            }
            if(BtnSave.Text== "Update")
            {
                int id = Convert.ToInt32(lblId.Text);
                
                using (AddressBookEntities addressBkEntities = new AddressBookEntities()) //it is good practice to use using statement, because it automatically calls dispose method if any exception occurs. also it closes the connction automatically.
                {
                    Address addressToUpdate = addressBkEntities.Addresses.Where(x => x.Id == id).Select(x => x).FirstOrDefault(); // we are selecting the specific row from table to update record - here we are selecting row where id = id from lable field.
                    addressToUpdate.Name = txtName.Text;
                    addressToUpdate.AddressLine1 = txtAddres.Text;
                    addressToUpdate.City = txtCity.Text;
                    addressToUpdate.Country = txtCountry.Text;
                    addressToUpdate.Contact = txtContact.Text;
                    addressBkEntities.SaveChanges();
                    clear();
                }
                
            }
            BindGrid(); //calls method to bind the grid with new result. 
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            clear();


        }
        void clear()
        {
            txtName.Text = txtAddres.Text = txtCity.Text = txtCountry.Text = txtContact.Text = "";


        }
        public void BindGrid()
        {
            AddressBookEntities addressBookEntities = new AddresBook.AddressBookEntities();
            List<Address> addressList = new List<AddresBook.Address>();
            addressList = addressBookEntities.Addresses.ToList();
            dataGridView1.DataSource = addressList;

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows) // foreach datagridview selected rows values  
                {
                    int id = Convert.ToInt32(row.Cells[0].Value); // we need this id to update record in the database. 
                    lblId.Text = id.ToString(); //lblId is hidden field - in designer set visible property to false. To create a hidden field, create a label in designer and set visible property to false.
                    txtName.Text = row.Cells[1].Value.ToString();
                    txtAddres.Text = row.Cells[2].Value.ToString();
                    txtCity.Text = row.Cells[3].Value.ToString();
                    txtCountry.Text = row.Cells[4].Value.ToString();
                    txtContact.Text = row.Cells[5].Value.ToString();

                }
            }
            BtnSave.Text = "Update";

        }
    }
}
